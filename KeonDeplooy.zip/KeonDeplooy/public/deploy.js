import formidable from "formidable";
import fs from "fs";
import fetch from "node-fetch";

export const config = { api: { bodyParser: false } };

export default async (req, res) => {
  const form = new formidable.IncomingForm();
  form.uploadDir = "/tmp";
  form.keepExtensions = true;

  form.parse(req, async (err, fields, files) => {
    if (err) return res.status(500).json({ error: "Upload gagal" });

    const siteName = fields.siteName;
    const filePath = files.file.filepath;

    // Token Vercel kamu (buat di https://vercel.com/account/tokens)
    const VERCEL_TOKEN = process.env.VERCEL_TOKEN;

    try {
      const data = fs.readFileSync(filePath);

      const response = await fetch("https://api.vercel.com/v13/deployments", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${VERCEL_TOKEN}`,
        },
        body: data,
      });

      const json = await response.json();
      if (json.url) {
        res.status(200).json({ url: "https://" + json.url });
      } else {
        res.status(400).json({ error: json.error?.message || "Gagal deploy" });
      }
    } catch (e) {
      res.status(500).json({ error: e.message });
    }
  });
};